create FUNCTION     "F$MACHINE" RETURN VARCHAR2 AS BEGIN RETURN DVSYS.get_factor(p_factor =>'Machine'); END;
/

