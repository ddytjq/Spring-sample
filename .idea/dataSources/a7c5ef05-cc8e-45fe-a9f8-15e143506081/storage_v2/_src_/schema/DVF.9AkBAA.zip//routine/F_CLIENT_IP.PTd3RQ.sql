create FUNCTION     "F$CLIENT_IP" RETURN VARCHAR2 AS BEGIN RETURN DVSYS.get_factor(p_factor =>'Client_IP'); END;
/

