create FUNCTION     "F$DATABASE_IP" RETURN VARCHAR2 AS BEGIN RETURN DVSYS.get_factor(p_factor =>'Database_IP'); END;
/

