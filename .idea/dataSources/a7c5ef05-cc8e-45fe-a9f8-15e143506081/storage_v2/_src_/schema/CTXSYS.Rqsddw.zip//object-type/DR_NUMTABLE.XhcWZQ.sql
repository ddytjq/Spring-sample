create type dr$numtable as table of number;
/

