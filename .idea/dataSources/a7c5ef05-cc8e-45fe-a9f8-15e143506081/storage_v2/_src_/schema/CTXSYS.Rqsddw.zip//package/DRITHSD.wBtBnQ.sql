create PACKAGE drithsd AS

/*------------------------------- dump_thesaurus -------------------------*/
/*
  NAME
    dump_thesaurus

  DESCRIPTION
    initializes package for thesaurus dumping

  ARGUMENTS
    name    (IN) thesaurus name (if not specified, DEFAULT is used)
*/

PROCEDURE dump_thesaurus (
  tname in varchar2
);

/*------------------------------- next_dump_line -------------------------*/
/*
  NAME
    next_dump_line

  DESCRIPTION
    get next dump line

  ARGUMENTS

  RETURN
    line, or NULL at EOD

  NOTES
    MUST call dump_thesaurus first
*/
FUNCTION next_dump_line RETURN VARCHAR2;

end drithsd;
/

