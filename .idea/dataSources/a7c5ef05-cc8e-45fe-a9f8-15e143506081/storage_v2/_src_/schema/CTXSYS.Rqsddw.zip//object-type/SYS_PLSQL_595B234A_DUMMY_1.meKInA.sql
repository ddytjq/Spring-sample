create type          SYS_PLSQL_595B234A_DUMMY_1 as table of number;
/

