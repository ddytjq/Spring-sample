create type          SYS_PLSQL_10CA3684_74_1 as object (DOCID NUMBER,
CATID NUMBER,
SCR NUMBER);
/

