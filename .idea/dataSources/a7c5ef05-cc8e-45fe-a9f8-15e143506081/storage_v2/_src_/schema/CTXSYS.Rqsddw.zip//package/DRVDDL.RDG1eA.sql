create package drvddl authid current_user as

  pv_idx_mem            number;
  pv_is_import          boolean;
  pv_master_params      varchar2(2000);
  pv_partition_populate boolean;

  px_partition_error    EXCEPTION;

  PARALLEL_OP  constant number :=  1;
  CREATE_OP    constant number := 16;
  RESUME_OP    constant number := 32;

  P_CREATE_OP  constant number := 16 + 1;
  P_RESUME_OP  constant number := 32 + 1;
  P_SYNC_OP    constant number := 64 + 1;

  -- 10169701: Keep track of any tokens which had errors during optimize
  -- rebuild
  type text_tab is table of varchar2(64) index by binary_integer;
  type type_tab is table of number index by binary_integer;
  opt_rebuild_error_text text_tab;
  opt_rebuild_error_type type_tab;

/*----------------------- PartitionCreate  -----------------------*/

PROCEDURE PartitionCreate(
  ia              in  sys.ODCIIndexInfo,
  owner           in  varchar2,
  index_name      in  varchar2,
  index_partition in  varchar2,
  table_owner     in  varchar2,
  table_name      in  varchar2,
  table_partition in  varchar2,
  idxmem          in  number,
  storage         in  varchar2,
  populate        in  boolean default TRUE,
  sync_type       in  varchar2 default NULL,
  sync_memory     in  varchar2 default NULL,
  sync_paradegree in  number   default NULL,
  sync_interval   in  varchar2 default NULL,
  is_online       in  boolean default FALSE,
  sync_dpl        in  boolean default FALSE
);

/*----------------------- IndexCreate  -----------------------*/
/*
  NAME
    IndexCreate

  DESCRIPTION
    create an index

  ARGUMENTS
    owner        index owner
    index_name   index name
    table_owner  table owner
    table_name   table name
    column_name  text column name
    column_type  text column type (optional)
    populate     populate/nopopulate
    para         parallel degree
    langcol      language column
    fmtcol       format column name
    csetcol      charset column name
    configcol    charset column name
    idxmem       index memory
    datastore    datastore pref name
    filter       filter pref name
    section      section group pref name
    lexer        lexer pref name
    wordlist     wordlist pref name
    stoplist     stoplist pref name
    storage      storage pref name
    txntional    transactional pref name
    tree         supports ctx_tree

  NOTES

  EXCEPTIONS

  RETURNS

*/
PROCEDURE IndexCreate(
  ia          in  sys.odciindexinfo,
  owner       in  varchar2,
  index_name  in  varchar2,
  index_part  in  varchar2,
  table_owner in  varchar2,
  table_name  in  varchar2,
  table_part  in  varchar2,
  column_name in  varchar2,
  column_type in varchar2,
  call_prop   in  number,
  populate    in  boolean,
  para        in  number,
  langcol     in  varchar2,
  fmtcol      in  varchar2,
  csetcol     in  varchar2,
  idxmem      in  number,
  datastore   in  varchar2,
  filter      in  varchar2,
  section     in  varchar2,
  lexer       in  varchar2,
  wordlist    in  varchar2,
  stoplist    in  varchar2,
  storage     in  varchar2,
  txntional   in  varchar2,
  sync_type   in  varchar2,
  sync_memory     in  varchar2,
  sync_paradegree in  number,
  sync_interval   in  varchar2,
  tree            in  boolean,
  sync_dpl        in  boolean,
  configcol     in  varchar2
);

/*----------------------- IndexDrop  -------------------------*/
/*
  NAME
    IndexDrop

  DESCRIPTION
    drop an index

  ARGUMENTS
    ia           index info
*/
PROCEDURE IndexDrop(
  ia          in  sys.ODCIIndexInfo,
  owner       in  varchar2,
  index_name  in  varchar2,
  call_prop   in  number
);

/*----------------------- IndexTruncate  ---------------------*/
/*
  NAME
    IndexTruncate

  DESCRIPTION
    truncate an index

  ARGUMENTS
    ia           index info
    owner        index owner
    index_name   index name
    ixp_name     index partition name
    call_prop    call property
*/
PROCEDURE IndexTruncate(
  ia           in sys.odciindexinfo,
  owner        in varchar2,
  index_name   in varchar2,
  ixp_name     in varchar2,
  call_prop    in number

);

/*----------------------- IndexTransport  -----------------------*/
/*
  NAME
    IndexTransport

  DESCRIPTION
    transport tablespace support

  ARGUMENTS
    owner        index owner
    index_name   index name
    index_part   index partition name
    table_owner  table owner
    table_name   table name
    table_part   table partition name

  NOTES

  EXCEPTIONS

  RETURNS

*/
PROCEDURE IndexTransport(
  owner       in  varchar2,
  index_name  in  varchar2,
  index_part  in  varchar2,
  table_owner in  varchar2,
  table_name  in  varchar2,
  table_part  in  varchar2,
  IndexInfoFlags in number,
  CallProperty   in number
);

/*----------------------- PartitionSplit  -----------------------*/
/*
  NAME
    PartitionSplit

  DESCRIPTION
    split one partition into two

  ARGUMENTS
    ia          ODCIIndexInfo for the spliting partition
    part1       ODCIPartInfo for resulting partition
    part2       ODCIPartInfo for resulting partition


  NOTES

  EXCEPTIONS

  RETURNS

*/
PROCEDURE PartitionSplit(
  ia              in  sys.odciindexinfo,
  part1           in  sys.odcipartinfo,
  part2           in  sys.odcipartinfo
);

/*----------------------- PartitionMerge  -----------------------*/
/*
  NAME
    PartitionMerge

  DESCRIPTION
    split one partition into two

  ARGUMENTS
    ia          ODCIIndexInfo for the resulting partition
    part1       ODCIPartInfo for one of the merging partitions
    part2       ODCIPartInfo for one of the merging  partition


  NOTES

  EXCEPTIONS

  RETURNS

*/
PROCEDURE PartitionMerge(
  ia              in  sys.odciindexinfo,
  part1           in  sys.odcipartinfo,
  part2           in  sys.odcipartinfo
);

/*----------------------- PartitionExchange  -----------------------*/
/*
  NAME
    PartitionExchange

  DESCRIPTION
    Swap a partition with a table

  ARGUMENTS
    ia          ODCIIndexInfo for the partition index to be exchanged
    ia1         ODCIIndexinfo for the index on the table


  NOTES

  EXCEPTIONS

  RETURNS

*/
PROCEDURE PartitionExchange(
  ia              in  sys.odciindexinfo,
  ia1             in  sys.odciindexinfo
);

/*----------------------- IndexRename  ---------------------*/
/*
  NAME
    IndexRename

  DESCRIPTION
    rename an index

  ARGUMENTS
    ia           index info
    owner        index owner
    index_name   index name
    new_name     new name
*/
PROCEDURE IndexRename(
  ia           in sys.odciindexinfo,
  owner        in varchar2,
  index_name   in varchar2,
  new_name     in varchar2
);

/*----------------------- IndexColRename  ---------------------*/
/*
  NAME
    IndexColRename

  DESCRIPTION
    rename an index column

  ARGUMENTS
    ia           index info
    owner        index owner
    index_name   index name
    new_name     new name
*/
PROCEDURE IndexColRename(
  ia           in sys.odciindexinfo,
  owner        in varchar2,
  index_name   in varchar2,
  new_name     in varchar2
);

/*----------------------- IndexReplace  -------------------------*/
/*
  NAME
    IndexReplace

  DESCRIPTION
    rebuild an index, replacing preferences as needed

  ARGUMENTS
    ia           index info
    idx          index record
    idxmem       index memory
    para         parallel degree
    langcol      language column
    fmtcol       format column name
    csetcol      charset column name
    configcol    configuration column name
    datastore    datastore pref name
    filter       filter pref name
    section      section group pref name
    lexer        lexer pref name
    wordlist     wordlist pref name
    stoplist     stoplist pref name
    storage      storage pref name
    isonline     is online ?
    sync_dpl     direct path loading?
    section_name section name
*/
PROCEDURE IndexReplace(
  ia          in  sys.ODCIIndexInfo,
  idx         in out nocopy  dr_def.idx_rec,
  idxmem      in  number,
  para        in  number,
  langcol     in  varchar2,
  fmtcol      in  varchar2,
  csetcol     in  varchar2,
  datastore   in  varchar2,
  filter      in  varchar2,
  section     in  varchar2,
  lexer       in  varchar2,
  wordlist    in  varchar2,
  stoplist    in  varchar2,
  storage     in  varchar2,
  txntional   in  varchar2,
  sync_type   in  varchar2,
  sync_memory     in   varchar2,
  sync_paradegree in   number,
  sync_interval   in   varchar2,
  isonline    in  boolean default FALSE,
  metadataonly in boolean default FALSE,
  populate     in boolean default TRUE,
  sync_dpl     in boolean default FALSE,
  section_name in varchar2 default NULL,
  configcol   in  varchar2 default NULL
);

/*----------------------- IndexPartReplace  -------------------------*/
/*
  NAME
    IndexPartReplace

  DESCRIPTION
    rebuild a index partition, replacing preferences as needed

  ARGUMENTS
    ia           index info
    idx          index record
    ixp          index partition
    idxmem       index memory
    storage      storage pref name
    para         parallel degree
*/
PROCEDURE IndexPartReplace(
  ia          in  sys.ODCIIndexInfo,
  idx         in  dr_def.idx_rec,
  ixp         in  dr_def.ixp_rec,
  idxmem      in  number,
  storage     in  varchar2,
  para        in  number,
  sync_type   in  varchar2,
  sync_memory     in   varchar2,
  sync_paradegree in   number,
  sync_interval   in   varchar2,
  isonline     in boolean default FALSE,
  metadataonly in boolean default FALSE,
  populate     in boolean default TRUE,
  sync_dpl     in boolean default FALSE
);

/*----------------------- IndexResume  -------------------------*/
/*
  NAME
    IndexResume

  DESCRIPTION
    resume index creation

  ARGUMENTS
    ia           index info
    idx          index record
    para         parallel degree
    idxmem       index memory
    isOnline     is online?
    isreplace    called from replace
*/
PROCEDURE IndexResume(
  ia          in  sys.ODCIIndexInfo,
  idx         in  dr_def.idx_rec,
  para        in  number,
  idxmem      in  number,
  isonline    in  boolean default FALSE,
  isreplace   in  boolean default FALSE,
  populate     in boolean default TRUE
);

/*----------------------- IndexPartResume  -------------------------*/
/*
  NAME
    IndexPartResume

  DESCRIPTION
    resume index creation on a partition

  ARGUMENTS
    ia           index info which also has partition info
    idx          index record
    para         parallel degree
    idxmem       index memory
*/
PROCEDURE IndexPartResume(
  ia          in  sys.ODCIIndexInfo,
  idx         in  dr_def.idx_rec,
  para        in  number,
  idxmem      in  number,
  isOnline    in  boolean default FALSE,
  isReplace   in  boolean default FALSE,
  populate    in  boolean default TRUE
);

/*----------------------- IndexOptimize  -------------------------*/
/*
  NAME
    IndexOptimize

  DESCRIPTION
    optimize the index

  ARGUMENTS
    idx          index record
    ixpname      partition name
    operation    FAST, FULL, or TOKEN
    maxtime      maxtime for gc
    token	 text token string
*/
PROCEDURE IndexOptimize(
  idx         in  dr_def.idx_rec,
  ixpname     in  varchar2,
  operation   in  varchar2,
  maxtime     in  number,
  token       in  varchar2,
  ttype       in  number default 0,
  pdegree     in  number default 1,
  memory      in  number default 0,
  background  in  number default 0
);

TYPE popcurtyp is ref cursor return ctxsys.dr$number_sequence%rowtype;

FUNCTION IndexOptimizeParFn(
  crsr        in popcurtyp,
  idxownid    in number,
  idxowner    in varchar2,
  idxname     in varchar2,
  ixpname     in varchar2,
  shadow_itab in varchar2,
  shadow_stab in varchar2,
  nextid     in number,
  optmode     in number,
  maxtime     in number,
  logfile     in varchar2,
  maxhash     in number,
  ttype       in number,
  background  in number
) return varchar2;

/*----------------------- SplitDollari  -------------------------*/
/*
  NAME
    SplitDollari

  DESCRIPTION
    Split the $I table into multiple $I tables

  ARGUMENTS
    idx          index record
    ixpname      the name of the partition whose $I table we are
                 splitting(the $I is not modified)
    mapping_tab  the table that maps rowids to partition names
    name_prefix  the name of the output table in case of less than
                 two partitions, a name to which the partition
                 name gets appended otherwise:
                 name_prefix||'_'||part_name
    tspace       the name of the tablespace where additional
                 mapping tables will be created (for cleanup
                 purposes in case of core dump)
*/
PROCEDURE SplitDollari(
  idx         in  dr_def.idx_rec,
  ixpname     in  varchar2,
  mapping_tab in  varchar2,
  name_prefix in  varchar2,
  tspace      in  varchar2 default null
);

/*----------------------- IndexSync  -------------------------*/
/*
  NAME
    IndexSync

  DESCRIPTION
    sync the index

  ARGUMENTS
    idx          index record
    idxmem       index memory
    ixpname      index partition name
    direct_path  should we use direct-path inserts ?
*/
PROCEDURE IndexSync(
  idx         in  dr_def.idx_rec,
  ixpname     in  varchar2,
  idxmem      in  number,
  parallel_degree in number default 1,
  direct_path in  boolean default false,
  maxtime     in  number,
  locking     in  number
);

/*----------------------- LockBaseTable  -------------------------*/
/*
  NAME
    LockBaseTable

  DESCRIPTION
    lock the base table

  ARGUMENTS
    table_own    name of table owner
    table_name   name of table
    table_part   name of table partition (if any)
*/
PROCEDURE LockBaseTable(
  table_own   in varchar2,
  table_name  in varchar2,
  table_part  in varchar2 default NULL
);

PROCEDURE ProcessOnlinePending (
  table_own        in varchar2,
  table_name       in varchar2,
  index_own        in varchar2,
  index_name       in varchar2,
  polid            in number,
  is_part          in boolean,
  is_online        in boolean,
  is_alter         in boolean,
  table_partition  in varchar2 default NULL,
  index_partition  in varchar2 default NULL
) ;

/*----------------------- CDIUpdate  -------------------------*/

PROCEDURE CDIUpdate(
  polid       in number,
  ia          in sys.odciindexinfo,
  env         in sys.ODCIEnv,
  ridlist     in sys.odciridlist,
  oldvallist  in sys.odcicolarrayvallist,
  newvallist  in sys.odcicolarrayvallist
);

PROCEDURE RIOCleanup(
  idx_shadow  in dr_def.idx_rec
);

PROCEDURE PartCleanup(
  idx_shadow   dr_def.idx_rec,
  ixp_shadow   dr_def.ixp_rec
);

FUNCTION CursorToBitVector(
  crsr    in popcurtyp,
  numbits in number) RETURN varchar2;

PROCEDURE add_big_io(
  idx in dr_def.idx_rec
);

PROCEDURE remove_big_io(
  idx in dr_def.idx_rec
);

PROCEDURE add_separate_offsets(
  idx in dr_def.idx_rec
);

PROCEDURE add_stage_itab(
  idx in dr_def.idx_rec,
  ixp       in dr_def.ixp_rec default NULL
);

PROCEDURE remove_stage_itab(
  idx in dr_def.idx_rec,
  ixp       in dr_def.ixp_rec default NULL
);

/*--------------------------- field_to_mdata -------------------------------*/
/* convert a field section to mdata */
PROCEDURE field_to_mdata(
  idx in dr_def.idx_rec,
  fsec in varchar2,
  read_only in boolean
);

/*------------------------ IndexMapLanguagesDriver -------------------------*/
/* Driver for IndexMapLanguages - partitioned and non partitioned case. */
procedure IndexMapLanguagesDriver(
  idx      in dr_def.idx_rec
);

/*--------------------------- IndexMapLanguages ---------------------------*/
/* Map language column in base table to mdata sections */
procedure IndexMapLanguages(
  idx      in dr_def.idx_rec,
  ixp      in dr_def.ixp_rec,
  pdegree  in number,
  flags    in binary_integer,
  sectyp   in binary_integer,
  hash_usable in number
);

/*---------------------- AddDocLexerMDATATokens ------------------------*/
/* Add DR$ML MDATA Tokens to $I */
PROCEDURE AddDocLexerMDATATokens(
  ia       in sys.ODCIIndexInfo,
  idx      in dr_def.idx_rec
);

/*---------------------- RemDocLexerMDATATokens ------------------------*/
/* Remove DR$ML MDATA Tokens from $I(s) */
PROCEDURE RemDocLexerMDATATokens(
  ia       in sys.ODCIIndexInfo,
  idx in dr_def.idx_rec
);

/*--------------------------- idx_add_slx ------------------------------*/
/* Add sublexer to the Index */
PROCEDURE idx_add_slx(
  ia        in sys.ODCIIndexInfo,
  idx       in dr_def.idx_rec,
  sub_lexer in varchar2,
  language  in varchar2,
  alt_value in varchar2,
  language_dependent in boolean default TRUE
);

/*--------------------------- idx_rem_slx ------------------------------*/
/* Remove sublexer from the Index */
PROCEDURE idx_rem_slx(
  ia        in sys.ODCIIndexInfo,
  idx       in dr_def.idx_rec,
  sub_lexer in varchar2
);

/*--------------------------- idx_add_sw ------------------------------*/
/* Add stopword to the Index */
PROCEDURE idx_add_sw(
  ia        in sys.ODCIIndexInfo,
  idx       in dr_def.idx_rec,
  stopword  in varchar2,
  language  in varchar2,
  language_dependent in boolean default TRUE,
  secname   in varchar2
);

/*--------------------------- idx_rem_sw ------------------------------*/
/* Remove stopword from the Index */
PROCEDURE idx_rem_sw(
  ia        in sys.ODCIIndexInfo,
  idx       in dr_def.idx_rec,
  stopword    in  varchar2,
  language    in  varchar2,
  for_all     in boolean default FALSE
);

/*--------------------------- repopulate_dollarn ---------------------------*/
/* repopulate_dollarn - repopulate $N as opposite of $K */
PROCEDURE repopulate_dollarn(
  idx       in dr_def.idx_rec,
  ixp       in dr_def.ixp_rec
);

/*------------------------------ set_read_mode -----------------------------*/
/* set_read_mode - Set read mode to TRUE/FALSE, for given partition */
PROCEDURE set_read_mode(
  ia        in sys.ODCIIndexInfo,
  idx       in dr_def.idx_rec,
  ixp       in dr_def.ixp_rec default NULL,
  read_mode in boolean
);

end drvddl;
/

