create type          SYS_PLSQL_10CA3684_DUMMY_1 as table of number;
/

