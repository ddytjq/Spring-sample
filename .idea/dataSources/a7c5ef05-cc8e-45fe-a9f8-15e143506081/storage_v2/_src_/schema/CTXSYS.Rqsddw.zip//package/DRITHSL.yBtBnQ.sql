create PACKAGE drithsl AS

/*---------------------------- create_thesaurus ---------------------------*/
/*
  NAME
    create_thesaurus

  DESCRIPTION
    specialized version of drithsc.create_thesaurus for thesaurus loader
*/

FUNCTION create_thesaurus (tname in varchar2, casesens in boolean)
return NUMBER;

/*---------------------------- create_phrase ---------------------------*/
/*
   NAME
     create_phrase

   DESCRIPTION
     Specialized version of drithsc.create_phrase for thesaurus loader
*/

function create_phrase (
  tid    in number,
  tcs    in boolean,
  phrase in varchar2,
  rel    in varchar2 default null,
  relid  in number   default null
) return number;

/*------------------------------- dump_thesaurus -------------------------*/
/*
  NAME
    dump_thesaurus

  DESCRIPTION
    Specialized version of drithsd.dump_thesaurus for thesaurus loader
*/

PROCEDURE dump_thesaurus (
  tname in varchar2
);

/*------------------------------- next_dump_line -------------------------*/
/*
  NAME
    next_dump_line

  DESCRIPTION
    Specialized version of drithsd.next_dump_line for thesaurus loader
*/
FUNCTION next_dump_line RETURN VARCHAR2;

/*------------------------------- allocate_ids  -------------------------*/
/*
  NAME
    allocate_ids

  DESCRIPTION
    allocate a list of thes ids and return the starting number of that list

  ARGUMENTS
    numalloc  (IN)  -- number of thesaurus id to be allocated
    start_id  (OUT) -- start id of the list of thesaurus id
*/
PROCEDURE allocate_ids (
  numalloc  in  number,
  start_id  out number
);
PRAGMA SUPPLEMENTAL_LOG_DATA(allocate_ids, AUTO);

/*------------------------------- insert_phrase -------------------------*/
PROCEDURE insert_phrase(
  phr_id        in  number,
  phr_thsid     in  number,
  phr_phrase    in  varchar2,
  phr_qualify   in  varchar2,
  phr_note      in  varchar2,
  phr_ringid    in  number
);
PRAGMA SUPPLEMENTAL_LOG_DATA(insert_phrase, AUTO);

PROCEDURE insert_bt(
  ths_thp_id  in number,
  ths_type    in varchar2,
  ths_bt      in number
);
PRAGMA SUPPLEMENTAL_LOG_DATA(insert_bt, AUTO);

PROCEDURE insert_fphrase(
  phr_thp_id    in number,
  phr_phrase    in varchar2,
  phr_type      in varchar2
);
PRAGMA SUPPLEMENTAL_LOG_DATA(insert_fphrase, AUTO);

PROCEDURE update_phrase(
  phr_thp_id   in number,
  phr_note     in varchar2
);
PRAGMA SUPPLEMENTAL_LOG_DATA(update_phrase, AUTO);

FUNCTION get_thsid_byname(
  thsname   in    varchar2
)
return number;

end drithsl;
/

