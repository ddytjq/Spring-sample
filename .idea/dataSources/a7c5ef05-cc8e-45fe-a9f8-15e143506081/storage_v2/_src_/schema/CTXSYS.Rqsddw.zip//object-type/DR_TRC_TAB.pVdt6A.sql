create type dr$trc_tab as table of dr$trc_rec;
/

