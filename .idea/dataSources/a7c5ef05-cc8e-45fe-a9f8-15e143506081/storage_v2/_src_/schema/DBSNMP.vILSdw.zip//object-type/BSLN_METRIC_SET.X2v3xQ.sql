create type bsln_metric_set as table of bsln_metric_t;
/

